<script>
export default{
  data(){
    return{
      borsh: "БОРЩ"
      }
    },
    methods:{
      cons(){
        console.log(this.borsh)
      }
    }
}
</script>
